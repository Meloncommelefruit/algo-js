//personnage John 
const personnage = {
    prenom: "John",
    santeMentale: 10
}

//playlist 
const musiques = ["Wouna-Tsew The Kid","Kiss Kiss-Chris Brown","Heartbreak Anniversary-Giveon","Lean on Me-Bill Withers","Anissa-Wejdene"]; 

// Fonction pour que la musique soit aléatoire
function choixMusique() {
    const index = Math.floor(Math.random()* musiques.length);
    return musiques[index];
}

//obj trajet
const trajet = {
    radio: musiques,
    feuxRouges: 30,
    changements: 0
}

// Trajet avec les feux rouges
for(let i = 0; i < trajet.feuxRouges; i++){
    const musique= choixMusique();
    console.log(`Au feu rouge ${i + 1}, la musique joué est : ${musique}, nombre de feux restant: ${trajet.feuxRouges - i - 1} `);

    if (musique === "Anissa-Wejdene"){
        personnage.santeMentale --;
        trajet.changements ++;

    if (personnage.santeMentale === 0){
        console.log("Explosion")
    }
  }
}

if (personnage.santeMentale > 0){
    console.log(`John est arrivé à destination. Il a changé ${trajet.changements} fois de taxis. Sa charge mentale est à ${personnage.santeMentale}`);
}